package edu.miu.waa.demoinclasslab1.dto.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ReqCommetDto {
    private String name;
}
