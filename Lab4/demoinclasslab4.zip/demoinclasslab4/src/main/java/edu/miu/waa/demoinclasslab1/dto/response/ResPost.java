package edu.miu.waa.demoinclasslab1.dto.response;

import lombok.*;

@Getter
@Setter
public class ResPost {
    private long id;
    private String title;
    private String author;
}
