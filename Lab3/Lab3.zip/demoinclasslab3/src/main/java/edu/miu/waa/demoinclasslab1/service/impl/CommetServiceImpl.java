package edu.miu.waa.demoinclasslab1.service.impl;

import edu.miu.waa.demoinclasslab1.service.CommetService;
import edu.miu.waa.demoinclasslab1.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

public class CommetServiceImpl implements CommetService {
    @Autowired
    CommetService commetService;
}
