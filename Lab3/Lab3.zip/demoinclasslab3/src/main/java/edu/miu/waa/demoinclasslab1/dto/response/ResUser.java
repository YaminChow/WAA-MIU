package edu.miu.waa.demoinclasslab1.dto.response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ResUser {
    private long id;
    private String name;
}
