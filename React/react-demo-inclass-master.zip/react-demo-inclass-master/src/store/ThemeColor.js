import React from "react";

export const ThemeColorContext = React.createContext();