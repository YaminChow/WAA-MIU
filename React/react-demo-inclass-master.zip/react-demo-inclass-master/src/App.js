
import './App.css';
import Dashboard from './pages/Dashboard/Dashboard';

function App() {
  return (
    <div className="App">
      <h1>Welcome to WAA</h1>
      <Dashboard />
    </div>
  );
}

export default App;
