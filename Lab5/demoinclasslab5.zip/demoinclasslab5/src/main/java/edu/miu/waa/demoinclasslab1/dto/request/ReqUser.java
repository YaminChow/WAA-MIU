package edu.miu.waa.demoinclasslab1.dto.request;

import lombok.Data;

@Data
public class ReqUser {
    private long id;
}
