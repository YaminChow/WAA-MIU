package edu.miu.waa.demoinclasslab1.dto.response;

public class ResUserPostComment {
}
