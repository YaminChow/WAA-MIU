package edu.miu.waa.demoinclasslab1.service;

import edu.miu.waa.demoinclasslab1.entity.Logger;

public interface LoggerService {
    void saveLog(Logger logger);
}
