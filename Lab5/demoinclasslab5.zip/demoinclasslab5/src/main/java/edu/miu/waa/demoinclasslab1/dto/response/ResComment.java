package edu.miu.waa.demoinclasslab1.dto.response;

public class ResComment {
    private long id;
    private String name;

}
