package edu.miu.waa.demoinclasslab1.service;

import edu.miu.waa.demoinclasslab1.entity.ExceptionLogger;

public interface ExceptionLoggerService {
    void saveExceptionLogger(ExceptionLogger exceptionLogger);
}
