
import './App.css';
import Dashboard from './containers/Dashboard';

function App() {
  return (
    
      <div className="App">
          <h1> Welcome WAA </h1>
          <Dashboard />
        
      </div>
    
  );
}

export default App;
