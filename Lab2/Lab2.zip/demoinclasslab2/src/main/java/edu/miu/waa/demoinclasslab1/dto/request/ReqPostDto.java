package edu.miu.waa.demoinclasslab1.dto.request;

import lombok.Data;

@Data
public class ReqPostDto {
    private String title;
    private String content;
    private String author;
}
